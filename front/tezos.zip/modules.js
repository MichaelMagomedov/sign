module.exports = [
    'admin',
    'auth'
];